#include "baiduvoice.h"

baiduVoice::baiduVoice()
{
//    VOP_append["format"] = "pcm";
//    VOP_append["rate"] = 8000;
//    VOP_append["channel"] = 1;
//    VOP_append["token"] = Access_Token;
//    VOP_append["lan"] = "zh";
//    VOP_append["cuid"] = MAC_cuid;
}
