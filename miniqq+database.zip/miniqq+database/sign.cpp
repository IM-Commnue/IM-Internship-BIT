#include "sign.h"
#include "ui_sign.h"
#include "dialog.h"
#include "database.h"

sign::sign(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::sign)
{
    ui->setupUi(this);
//.cpp
        QPalette pa(this->palette());
        QImage img = QImage(":/red/02.png");
        img = img.scaled(this->size());
        QBrush *pic = new QBrush(img);
        pa.setBrush(QPalette::Window,*pic);
        //this->setAutoFillBackground(true);
        this->setPalette(pa);
}

sign::~sign()
{
    delete ui;
}

void sign::on_cancelbutton_clicked()
{
    this->close();
}

void sign::on_confirmbutton_clicked()
{
    QString username = ui->usernamelineEdit->text();
    QString mail = ui->lineEdit->text();
    QString password = ui->codelineEditit->text();
    QString password_confirm = ui->codelineEdit_2->text();
    qDebug()<<username<<mail<< password<< password_confirm;
    DataBase database;
    database.connect_database("test.db");
    if(!database.database_tabal_exist("user")){
            database.database_tabal_creat("create table user(\
                                              username varchar(50) primary key,\
                                              password varchar(50),\
                                              mail varchar(50),\
                                              nickname varchar(50))");
    }
    bool username_correct = database.database_username_repetition(username.toStdString().c_str());
    if (!username_correct){
        QMessageBox::warning(this,tr("错误"),tr("该用户名已被注册！"),QMessageBox::Yes);
        return;
    }
    if (!database.password_correct(password.toStdString().c_str())){
        QMessageBox::warning(this,tr("错误"),tr(
                                 "密码不符合要求！\n需要同时包含大小写字母、数字、符号且大于八位！"),
                                 QMessageBox::Yes);
        return;
    }
    if (!database.mail_correct(mail.toStdString().c_str())){
        QMessageBox::warning(this,tr("错误"),tr("邮箱格式有误"), QMessageBox::Yes);
        return;
    }
    if(password!=password_confirm)
    {
        QMessageBox::warning(this,tr("错误"),tr("两次输入密码不一致！"),QMessageBox::Yes);
        return;
    }
    QString nickname = NULL;
    database.database_username_insert(this,"user",username.toStdString().c_str(),
                                      password.toStdString().c_str(),mail.toStdString().c_str(),
                                      nickname.toStdString().c_str());
    QMessageBox::warning(this,tr("正确"),tr("注册成功"),QMessageBox::Yes);

    database.disconnect_database();

    Dialog* d = new Dialog();
    d->show();
    this->close();

}
