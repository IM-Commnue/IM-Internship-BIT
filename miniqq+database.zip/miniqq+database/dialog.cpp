#include "dialog.h"
#include "sign.h"
#include "ui_dialog.h"
#include "qtmaterialautocomplete.h"
#include "database.h"
#include <QMessageBox>
#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>
#include <QDebug>
#include <QDir>
#include <QAction>


Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    ui->setupUi(this);
    //背景图片设置
    ui->Qlabel->setPixmap(QPixmap(":red/02.png"));
    ui->Qlabel->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    ui->Qlabel->setScaledContents(true);
    //密码眼睛操作实现
    QAction *action = new QAction(this);
    action->setIcon(QIcon(":/eye/closecat.png"));
    int stat = 0;
    connect(ui->pwdLineEdit, &QtMaterialAutoComplete::textEdited, [=]() {
            static bool first = true;
                if (first) {
                            ui->pwdLineEdit->addAction(action, QLineEdit::TrailingPosition);
                            first = false;
                           }
            });

    connect(action, &QAction::triggered, [=, &stat]() {
            if (stat == 0) {
                        action->setIcon(QIcon(":/eye/cat.png"));
                        ui->pwdLineEdit->addAction(action, QLineEdit::TrailingPosition);
                        stat = 1;
                        ui->pwdLineEdit->setEchoMode(QLineEdit::Normal);
                        }
            else
            {
                action->setIcon(QIcon(":/eye/closecat.png"));
                ui->pwdLineEdit->addAction(action, QLineEdit::TrailingPosition);
                stat = 0;
                ui->pwdLineEdit->setEchoMode(QLineEdit::Password);
            }
    });
    //新功能实现区：

}

Dialog::~Dialog()
{
    delete ui;
}

void Dialog::on_loginBtn_clicked()
{
    QString username = ui->usrLineEdit->text();
    QString password = ui->pwdLineEdit->text();
    DataBase database;
    database.connect_database("test.db");
    bool isFound = database.login(username.toStdString().c_str(), password.toStdString().c_str());
    qDebug()<<isFound;
    if(isFound)
    {
        QMessageBox::information(NULL, tr("Note"), tr("Login success!"));
           accept();
    }else {
        QMessageBox::warning(this, tr("Waring"),
                              tr("user name or password error!"),
                              QMessageBox::Yes);
        // 清空内容并定位光标
        ui->usrLineEdit->clear();
        ui->pwdLineEdit->clear();
        ui->usrLineEdit->setFocus();
     }
    database.disconnect_database();
}



void Dialog::on_signBtn_clicked()
{
    sign *s=new sign();
    s->exec();
}
