#include "chatwindow.h"

ChatWindow::ChatWindow()
{

}
