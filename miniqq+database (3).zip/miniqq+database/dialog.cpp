#include "dialog.h"
#include "sign.h"
#include "ui_dialog.h"
#include "qtmaterialautocomplete.h"
#include "database.h"
#include <QMessageBox>
#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>
#include <QDebug>
#include <QDir>
#include <QAction>



Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    ui->setupUi(this);
    // 创建通信的套接字对象
    m_tcp = new QTcpSocket(this);
    //背景图片设置
    ui->Qlabel->setPixmap(QPixmap(":red/02.png"));
    ui->Qlabel->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    ui->Qlabel->setScaledContents(true);
    //密码眼睛操作实现
    QAction *action = new QAction(this);
    action->setIcon(QIcon(":/eye/closecat.png"));
    int stat = 0;
    connect(ui->pwdLineEdit, &QtMaterialAutoComplete::textEdited, [=]() {
            static bool first = true;
                if (first) {
                            ui->pwdLineEdit->addAction(action, QLineEdit::TrailingPosition);
                            first = false;
                           }
            });
    connect(m_tcp, &QTcpSocket::readyRead, [=]()
        {
            // 接收服务器发送的数据
            QByteArray recvMsg = m_tcp->readAll();
            std::string recvStr = recvMsg.toStdString();

        });



    connect(action, &QAction::triggered, [=, &stat]() {
            if (stat == 0) {
                        action->setIcon(QIcon(":/eye/cat.png"));
                        ui->pwdLineEdit->addAction(action, QLineEdit::TrailingPosition);
                        stat = 1;
                        ui->pwdLineEdit->setEchoMode(QLineEdit::Normal);
                        }
            else
            {
                action->setIcon(QIcon(":/eye/closecat.png"));
                ui->pwdLineEdit->addAction(action, QLineEdit::TrailingPosition);
                stat = 0;
                ui->pwdLineEdit->setEchoMode(QLineEdit::Password);
            }
    });
    //新功能实现区：

}

Dialog::~Dialog()
{
    delete ui;
}

void Dialog::on_loginBtn_clicked()
{
    QString username = ui->usrLineEdit->text();
    QString password = ui->pwdLineEdit->text();

    //连接服务器
    QString ip = "172.20.10.5";
    int port = 9989;
    m_tcp->connectToHost(QHostAddress(ip), port);

    // 创建 JSON 对象并设置用户名和密码字段
    QJsonObject jsonObject;
    jsonObject["class"] = "log"; // json类型为登录
    jsonObject["username"] = username;
    jsonObject["password"] = password;

    // 创建 JSON 文档
    QJsonDocument jsonDoc(jsonObject);

    // 将 JSON 文档转换为字符串
    QString jsonString = QString::fromUtf8(jsonDoc.toJson());

    // 发送 JSON 字符串
    m_tcp->write(jsonString.toUtf8());

    if(recvStr == "1")
    {
        QMessageBox::information(NULL, tr("Note"), tr("Login success!"));
           accept();
    }else {
        QMessageBox::warning(this, tr("Waring"),
                              tr("user name or password error!"),
                              QMessageBox::Yes);        // 清空内容并定位光标
        ui->usrLineEdit->clear();
        ui->pwdLineEdit->clear();
        ui->usrLineEdit->setFocus();
     }

}



void Dialog::on_signBtn_clicked()
{
    sign *s=new sign();
    s->exec();
}

void Dialog::on_resignButton_clicked()
{

}
