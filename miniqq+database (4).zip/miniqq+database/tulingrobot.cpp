#include "tulingrobot.h"

TulingRobot::TulingRobot()
{

}
