#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QDialog>
#include <QUdpSocket>
#include <QTcpSocket>

QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent ,QString name);
    ~Widget();

    enum Msgtype{Msg,UserRnter,UserLeft};
    void sndMsg(Msgtype type);
    QString getName();
    QString getMsg();
    void userEnter();
    void userLeft();
    void ReceiveMessage();

    //重写关闭事件
    void closeEvent(QCloseEvent *);
signals:
    void closeWidget();

private slots:
    void on_pushButton_clicked();
    void on_tableWidget_customContextMenuRequested(const QPoint &pos);
    void on_exitpushButton_clicked();
    void sendData();

private:
    Ui::Widget *ui;
    QTcpSocket *m_socket;//TCP客户端对象
    QString myname;

    QUdpSocket *udpSocket;//udp 套接字

    QString m_host = "120.0.0.1"; //服务器IP地址
    int m_port = 8899; //服务器端口号

protected:

};
#endif // WIDGET_H
